class AnimationConstants {
  // static String loading = "assets/animations/loading_animation.json";
  static String loading = "assets/animations/unloaking_animation.json";
  static String loading2 = "assets/animations/loading_animation.json";
}
